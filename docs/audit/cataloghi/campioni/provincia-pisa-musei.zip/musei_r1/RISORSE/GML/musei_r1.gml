<?xml version="1.0" encoding="utf-8" ?>
<ogr:FeatureCollection
     gml:id="aFeatureCollection"
     xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
     xsi:schemaLocation="http://ogr.maptools.org/ musei_r1.xsd"
     xmlns:ogr="http://ogr.maptools.org/"
     xmlns:gml="http://www.opengis.net/gml/3.2">
  <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1611765.21645174 4781091.49789125</gml:lowerCorner><gml:upperCorner>1658977.31815321 4848624.9305475</gml:upperCorner></gml:Envelope></gml:boundedBy>
                                                                                                                   
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.0">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1622690.57261667 4842119.14183868</gml:lowerCorner><gml:upperCorner>1622690.57261667 4842119.14183868</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.0"><gml:pos>1622690.57261667 4842119.14183868</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.0</ogr:fid>
      <ogr:nome>Museo di storia naturale e del territorio</ogr:nome>
      <ogr:comune>CALCI</ogr:comune>
      <ogr:indirizzo>Viale Roma, 79</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia e scienze naturali</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.1">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1638199.27963176 4832026.26665872</gml:lowerCorner><gml:upperCorner>1638199.27963176 4832026.26665872</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.1"><gml:pos>1638199.27963176 4832026.26665872</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.1</ogr:fid>
      <ogr:nome>Museo del Lavoro e della Civilta' Rurale</ogr:nome>
      <ogr:comune>PALAIA</ogr:comune>
      <ogr:indirizzo>Via Palaiese, 30</ogr:indirizzo>
      <ogr:localita>San Gervasio</ogr:localita>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>sl</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.2">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612348.46502404 4842165.35143857</gml:lowerCorner><gml:upperCorner>1612348.46502404 4842165.35143857</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.2"><gml:pos>1612348.46502404 4842165.35143857</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.2</ogr:fid>
      <ogr:nome>Camposanto Monumentale</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Piazza del Duomo, 17</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.3">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612547.92393541 4842022.04742286</gml:lowerCorner><gml:upperCorner>1612547.92393541 4842022.04742286</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.3"><gml:pos>1612547.92393541 4842022.04742286</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.3</ogr:fid>
      <ogr:nome>Museo dell'Opera del Duomo</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Piazza Arcivescovado, 6</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.4">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612391.857131 4842007.16698823</gml:lowerCorner><gml:upperCorner>1612391.857131 4842007.16698823</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.4"><gml:pos>1612391.857131 4842007.16698823</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.4</ogr:fid>
      <ogr:nome>Museo delle Sinopie</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Piazza del Duomo</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>sv</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.5">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612405.86848799 4841777.06291682</gml:lowerCorner><gml:upperCorner>1612405.86848799 4841777.06291682</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.5"><gml:pos>1612405.86848799 4841777.06291682</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.5</ogr:fid>
      <ogr:nome>Museo di Anatomia umana del dipartimento di morfologia umana e biologia applicata</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Roma, 55</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia e scienze naturali</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.6">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612405.31348027 4841798.74949874</gml:lowerCorner><gml:upperCorner>1612405.31348027 4841798.74949874</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.6"><gml:pos>1612405.31348027 4841798.74949874</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.6</ogr:fid>
      <ogr:nome>Museo di Anatomia e Patologia</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Roma, 57</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia e scienze naturali</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.7">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612568.83074888 4841710.55234742</gml:lowerCorner><gml:upperCorner>1612568.83074888 4841710.55234742</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.7"><gml:pos>1612568.83074888 4841710.55234742</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.7</ogr:fid>
      <ogr:nome>Museo botanico</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Luca Ghini, 5</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Scienza</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.8">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612648.3724117 4841568.62610705</gml:lowerCorner><gml:upperCorner>1612648.3724117 4841568.62610705</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.8"><gml:pos>1612648.3724117 4841568.62610705</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.8</ogr:fid>
      <ogr:nome>Gipsoteca</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Galvani, 1</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.9">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612546.49968242 4841557.56769454</gml:lowerCorner><gml:upperCorner>1612546.49968242 4841557.56769454</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.9"><gml:pos>1612546.49968242 4841557.56769454</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.9</ogr:fid>
      <ogr:nome>Collezioni Paletnologiche e Paleontologiche</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Santa Maria, 53</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Scienza</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.10">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612805.8172429 4841563.80278277</gml:lowerCorner><gml:upperCorner>1612805.8172429 4841563.80278277</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.10"><gml:pos>1612805.8172429 4841563.80278277</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.10</ogr:fid>
      <ogr:nome>Collezioni egittologiche</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via San Frediano, 12</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.11">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1613427.28687463 4841191.7795956</gml:lowerCorner><gml:upperCorner>1613427.28687463 4841191.7795956</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.11"><gml:pos>1613427.28687463 4841191.7795956</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.11</ogr:fid>
      <ogr:nome>Gabinetto Disegni e Stampe</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Piazza San Matteo in Soarta, 2</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.12">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1613408.76798156 4841153.51042406</gml:lowerCorner><gml:upperCorner>1613408.76798156 4841153.51042406</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.12"><gml:pos>1613408.76798156 4841153.51042406</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.12</ogr:fid>
      <ogr:nome>Museo Nazionale di San Matteo</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Piazza S. Matteo in Soarta, 1</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.13">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1613782.87859789 4840433.91192393</gml:lowerCorner><gml:upperCorner>1613782.87859789 4840433.91192393</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.13"><gml:pos>1613782.87859789 4840433.91192393</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.13</ogr:fid>
      <ogr:nome>Museo di Anatomia Veterinaria</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Viale delle Piagge, 2</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia e scienze naturali</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.14">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1649276.70564867 4837959.40009592</gml:lowerCorner><gml:upperCorner>1649276.70564867 4837959.40009592</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.14"><gml:pos>1649276.70564867 4837959.40009592</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.14</ogr:fid>
      <ogr:nome>Museo Diocesano</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo>Piazza Duomo, 1</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.15">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1653031.26074331 4788921.23293447</gml:lowerCorner><gml:upperCorner>1653031.26074331 4788921.23293447</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.15"><gml:pos>1653031.26074331 4788921.23293447</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.15</ogr:fid>
      <ogr:nome>Museo della Geotermia</ogr:nome>
      <ogr:comune>POMARANCE</ogr:comune>
      <ogr:indirizzo>Piazza Leopolda</ogr:indirizzo>
      <ogr:localita>Larderello</ogr:localita>
      <ogr:classe>Scienza e Tecnica</ogr:classe>
      <ogr:localizzaz>sl</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.16">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1650994.44410436 4807041.3469901</gml:lowerCorner><gml:upperCorner>1650994.44410436 4807041.3469901</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.16"><gml:pos>1650994.44410436 4807041.3469901</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.16</ogr:fid>
      <ogr:nome>Museo Etrusco &quot;Guarnacci&quot;</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo>Via Don Minzoni, 15 Palazzo Desideri Tangassi</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.17">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1650602.41893018 4807249.84360475</gml:lowerCorner><gml:upperCorner>1650602.41893018 4807249.84360475</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.17"><gml:pos>1650602.41893018 4807249.84360475</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.17</ogr:fid>
      <ogr:nome>Pinacoteca e Museo Civico</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo>Via dei Sarti, 1</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.18">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1650559.46666359 4807175.84028446</gml:lowerCorner><gml:upperCorner>1650559.46666359 4807175.84028446</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.18"><gml:pos>1650559.46666359 4807175.84028446</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.18</ogr:fid>
      <ogr:nome>Museo Diocesano di Arte Sacra</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo>Via Roma, 13</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.19">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1630537.5825109 4840951.85000582</gml:lowerCorner><gml:upperCorner>1630537.5825109 4840951.85000582</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.19"><gml:pos>1630537.5825109 4840951.85000582</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.19</ogr:fid>
      <ogr:nome>Museo d'arte sacra della Pieve di Santa Maria Assunta</ogr:nome>
      <ogr:comune>BIENTINA</ogr:comune>
      <ogr:indirizzo>Borgo della Pieve, 2</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.20">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1630494.56117743 4840866.35987396</gml:lowerCorner><gml:upperCorner>1630494.56117743 4840866.35987396</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.20"><gml:pos>1630494.56117743 4840866.35987396</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.20</ogr:fid>
      <ogr:nome>Museo Etrusco e della Storia Antica del Territorio</ogr:nome>
      <ogr:comune>BIENTINA</ogr:comune>
      <ogr:indirizzo>Vicolo Masaccio, 1</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.21">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1635523.01795062 4826735.75638803</gml:lowerCorner><gml:upperCorner>1635523.01795062 4826735.75638803</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.21"><gml:pos>1635523.01795062 4826735.75638803</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.21</ogr:fid>
      <ogr:nome>Museo zoologico &quot;Villa Baciocchi&quot;</ogr:nome>
      <ogr:comune>CAPANNOLI</ogr:comune>
      <ogr:indirizzo>Piazza Castello, 1-4</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia e scienze naturali</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.22">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1625140.33008619 4837130.90738812</gml:lowerCorner><gml:upperCorner>1625140.33008619 4837130.90738812</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.22"><gml:pos>1625140.33008619 4837130.90738812</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.22</ogr:fid>
      <ogr:nome>Museo dei Mestieri e delle Arti del legno</ogr:nome>
      <ogr:comune>CASCINA</ogr:comune>
      <ogr:indirizzo>Via Tosco Romagnola, 238 presso la Mostra Permanente del Mobilio</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia e tradizioni popolari</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.23">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1640566.2612392 4840048.42350266</gml:lowerCorner><gml:upperCorner>1640566.2612392 4840048.42350266</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.23"><gml:pos>1640566.2612392 4840048.42350266</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.23</ogr:fid>
      <ogr:nome>Museo Archeologico</ogr:nome>
      <ogr:comune>CASTELFRANCO DI SOTTO</ogr:comune>
      <ogr:indirizzo>Via Galileo, 37 c/o Antica Chiesa di Santa Chiara</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.24">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1627572.94979073 4807841.92322452</gml:lowerCorner><gml:upperCorner>1627572.94979073 4807841.92322452</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.24"><gml:pos>1627572.94979073 4807841.92322452</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.24</ogr:fid>
      <ogr:nome>Ecomuseo dell'Alabastro</ogr:nome>
      <ogr:comune>CASTELLINA MARITTIMA</ogr:comune>
      <ogr:indirizzo>Piazza Cavour 1, ex Palazzo Opera &quot;Massimino Carrai&quot;</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.25">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1628597.44048015 4824949.08616638</gml:lowerCorner><gml:upperCorner>1628597.44048015 4824949.08616638</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.25"><gml:pos>1628597.44048015 4824949.08616638</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.25</ogr:fid>
      <ogr:nome>Castello dei Vicari e Museo Civico &quot;F. Baldinucci&quot;</ogr:nome>
      <ogr:comune>LARI</ogr:comune>
      <ogr:indirizzo>P.zza Castello, 1</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.26">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1641734.93659 4826438.55228989</gml:lowerCorner><gml:upperCorner>1641734.93659 4826438.55228989</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.26"><gml:pos>1641734.93659 4826438.55228989</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.26</ogr:fid>
      <ogr:nome>Museo della Civilta' Contadina</ogr:nome>
      <ogr:comune>PALAIA</ogr:comune>
      <ogr:indirizzo>Via A. Vaccà, 49</ogr:indirizzo>
      <ogr:localita>Montefoscoli</ogr:localita>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.27">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1639052.10575887 4823102.7563239</gml:lowerCorner><gml:upperCorner>1639052.10575887 4823102.7563239</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.27"><gml:pos>1639052.10575887 4823102.7563239</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.27</ogr:fid>
      <ogr:nome>Museo delle Icone Russe</ogr:nome>
      <ogr:comune>PECCIOLI</ogr:comune>
      <ogr:indirizzo>Piazza del Popolo, 5</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.28">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612645.76014966 4841557.17693021</gml:lowerCorner><gml:upperCorner>1612645.76014966 4841557.17693021</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.28"><gml:pos>1612645.76014966 4841557.17693021</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.28</ogr:fid>
      <ogr:nome>Antiquarium</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Galvani, 2</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.29">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612561.68329049 4841339.42468279</gml:lowerCorner><gml:upperCorner>1612561.68329049 4841339.42468279</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.29"><gml:pos>1612561.68329049 4841339.42468279</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.29</ogr:fid>
      <ogr:nome>Museo Nazionale di Palazzo Reale</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Lung.no Pacinotti, 46</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.30">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612110.67009546 4841388.83738507</gml:lowerCorner><gml:upperCorner>1612110.67009546 4841388.83738507</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.30"><gml:pos>1612110.67009546 4841388.83738507</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.30</ogr:fid>
      <ogr:nome>Museo degli strumenti per il calcolo</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Nicola Pisano, 25</ogr:indirizzo>
      <ogr:localita>Area dei Vecchi Macelli</ogr:localita>
      <ogr:classe>Scienza e Tecnica</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.31">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612568.89742692 4841704.59511928</gml:lowerCorner><gml:upperCorner>1612568.89742692 4841704.59511928</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.31"><gml:pos>1612568.89742692 4841704.59511928</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.31</ogr:fid>
      <ogr:nome>Orto botanico</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Luca Ghini, 5</ogr:indirizzo>
      <ogr:localita>(Dipartimento di Scienze Botan</ogr:localita>
      <ogr:classe>Storia e scienze naturali</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.32">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1631671.54001771 4835516.66351806</gml:lowerCorner><gml:upperCorner>1631671.54001771 4835516.66351806</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.32"><gml:pos>1631671.54001771 4835516.66351806</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.32</ogr:fid>
      <ogr:nome>Museo Piaggio &quot;Giovanni Alberto Agnelli&quot;</ogr:nome>
      <ogr:comune>PONTEDERA</ogr:comune>
      <ogr:indirizzo>Viale Rinaldo Piaggio, 7</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.33">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1648709.12419451 4837625.98797813</gml:lowerCorner><gml:upperCorner>1648709.12419451 4837625.98797813</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.33"><gml:pos>1648709.12419451 4837625.98797813</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.33</ogr:fid>
      <ogr:nome>Conservatorio di Santa Chiara</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo>Via Roma, 15</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.34">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1649032.9282205 4837944.04805351</gml:lowerCorner><gml:upperCorner>1649032.9282205 4837944.04805351</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.34"><gml:pos>1649032.9282205 4837944.04805351</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.34</ogr:fid>
      <ogr:nome>Museo Archeologico</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo>Via Ser Ridolfo, 3</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.35">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1648312.95190608 4839254.6092429</gml:lowerCorner><gml:upperCorner>1648312.95190608 4839254.6092429</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.35"><gml:pos>1648312.95190608 4839254.6092429</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.35</ogr:fid>
      <ogr:nome>Museo della Scrittura</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo>Via De Amicis, 34</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.36">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1649196.30873836 4837949.51230001</gml:lowerCorner><gml:upperCorner>1649196.30873836 4837949.51230001</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.36"><gml:pos>1649196.30873836 4837949.51230001</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.36</ogr:fid>
      <ogr:nome>Raccolta d'arte Arciconfraternita della Misericordia</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo>Via Augusto Conti, 42</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.37">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1626694.82607398 4814506.23090543</gml:lowerCorner><gml:upperCorner>1626694.82607398 4814506.23090543</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.37"><gml:pos>1626694.82607398 4814506.23090543</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.37</ogr:fid>
      <ogr:nome>Ecomuseo dell'Alabastro</ogr:nome>
      <ogr:comune>SANTA LUCE</ogr:comune>
      <ogr:indirizzo>Piazza Rimembranza, 14 ex Palazzo Comunale</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.38">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1650603.60593339 4807244.58475678</gml:lowerCorner><gml:upperCorner>1650603.60593339 4807244.58475678</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.38"><gml:pos>1650603.60593339 4807244.58475678</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.38</ogr:fid>
      <ogr:nome>Ecomuseo dell'Alabastro</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo>Via dei Sarti, 1 Palazzo Minucci Solaini - Torri Minucci</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.39">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1650923.69530944 4807093.61507151</gml:lowerCorner><gml:upperCorner>1650923.69530944 4807093.61507151</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.39"><gml:pos>1650923.69530944 4807093.61507151</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.39</ogr:fid>
      <ogr:nome>Museo Storico dell'Alabastro</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo>Piazza XX Settembre 5</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia e tradizioni popolari</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.40">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1633902.53907614 4848624.9305475</gml:lowerCorner><gml:upperCorner>1633902.53907614 4848624.9305475</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.40"><gml:pos>1633902.53907614 4848624.9305475</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.40</ogr:fid>
      <ogr:nome>Museo Archeologico di Orentano</ogr:nome>
      <ogr:comune>CASTELFRANCO DI SOTTO</ogr:comune>
      <ogr:indirizzo>Via Martiri della libertà c/o i locali del Vecchio Teatro</ogr:indirizzo>
      <ogr:localita>Orentano</ogr:localita>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>sv</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.41">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1658977.31815321 4792222.96404963</gml:lowerCorner><gml:upperCorner>1658977.31815321 4792222.96404963</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.41"><gml:pos>1658977.31815321 4792222.96404963</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.41</ogr:fid>
      <ogr:nome>Museo della civiltà contadina</ogr:nome>
      <ogr:comune>CASTELNUOVO DI VAL DI CECINA</ogr:comune>
      <ogr:indirizzo>Via del Borgo</ogr:indirizzo>
      <ogr:localita>Montecastelli Pisano</ogr:localita>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.42">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1641971.25466815 4836648.49713442</gml:lowerCorner><gml:upperCorner>1641971.25466815 4836648.49713442</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.42"><gml:pos>1641971.25466815 4836648.49713442</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.42</ogr:fid>
      <ogr:nome>Museo Civico Palazzo &quot;Guicciardini&quot;</ogr:nome>
      <ogr:comune>MONTOPOLI IN VAL D'ARNO</ogr:comune>
      <ogr:indirizzo>Via Guicciardini, 55</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.43">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1641874.09705278 4805830.46682994</gml:lowerCorner><gml:upperCorner>1641874.09705278 4805830.46682994</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.43"><gml:pos>1641874.09705278 4805830.46682994</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.43</ogr:fid>
      <ogr:nome>Museo delle Miniere 2a sede per Centro di documentazione</ogr:nome>
      <ogr:comune>MONTECATINI VAL DI CECINA</ogr:comune>
      <ogr:indirizzo>Piazza Garibaldi, 1</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.44">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1622875.48435787 4842178.62502045</gml:lowerCorner><gml:upperCorner>1622875.48435787 4842178.62502045</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.44"><gml:pos>1622875.48435787 4842178.62502045</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.44</ogr:fid>
      <ogr:nome>Museo Storico Artistico della Certosa</ogr:nome>
      <ogr:comune>CALCI</ogr:comune>
      <ogr:indirizzo>Via Roma, 79</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.45">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612541.2529463 4841806.74998342</gml:lowerCorner><gml:upperCorner>1612541.2529463 4841806.74998342</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.45"><gml:pos>1612541.2529463 4841806.74998342</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.45</ogr:fid>
      <ogr:nome>Gipsoteca</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.46">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612493.27442957 4841748.78124392</gml:lowerCorner><gml:upperCorner>1612493.27442957 4841748.78124392</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.46"><gml:pos>1612493.27442957 4841748.78124392</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.46</ogr:fid>
      <ogr:nome>Barbarium Horti Pisani</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.47">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612561.24315675 4841482.90626912</gml:lowerCorner><gml:upperCorner>1612561.24315675 4841482.90626912</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.47"><gml:pos>1612561.24315675 4841482.90626912</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.47</ogr:fid>
      <ogr:nome>Domus Galileana</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.48">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612487.27638156 4841438.90626464</gml:lowerCorner><gml:upperCorner>1612487.27638156 4841438.90626464</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.48"><gml:pos>1612487.27638156 4841438.90626464</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.48</ogr:fid>
      <ogr:nome>Collezioni Egittologiche</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.49">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1613085.00879875 4841640.81248219</gml:lowerCorner><gml:upperCorner>1613085.00879875 4841640.81248219</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.49"><gml:pos>1613085.00879875 4841640.81248219</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.49</ogr:fid>
      <ogr:nome>Gabinetto Disegni e Stampe</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.50">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612675.48807804 4840808.52981304</gml:lowerCorner><gml:upperCorner>1612675.48807804 4840808.52981304</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.50"><gml:pos>1612675.48807804 4840808.52981304</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.50</ogr:fid>
      <ogr:nome>Domus Mazziniana</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Mazzini, 71</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.51">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612447.57813743 4832810.87499039</gml:lowerCorner><gml:upperCorner>1612447.57813743 4832810.87499039</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.51"><gml:pos>1612447.57813743 4832810.87499039</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.51</ogr:fid>
      <ogr:nome>Museo Cartografico Naturalistico</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.52">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1643643.04298578 4841388.50001347</gml:lowerCorner><gml:upperCorner>1643643.04298578 4841388.50001347</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.52"><gml:pos>1643643.04298578 4841388.50001347</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.52</ogr:fid>
      <ogr:nome>Museo della zona del cuoio</ogr:nome>
      <ogr:comune>SANTA CROCE SULL'ARNO</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.53">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1648925.64061413 4837837.31247928</gml:lowerCorner><gml:upperCorner>1648925.64061413 4837837.31247928</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.53"><gml:pos>1648925.64061413 4837837.31247928</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.53</ogr:fid>
      <ogr:nome>Collezione Cassa Risparmio di S.Miniato</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.54">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1653775.71095774 4811230.43750585</gml:lowerCorner><gml:upperCorner>1653775.71095774 4811230.43750585</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.54"><gml:pos>1653775.71095774 4811230.43750585</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.54</ogr:fid>
      <ogr:nome>Museo di arte sacra</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.55">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612550.71909057 4841485.77342483</gml:lowerCorner><gml:upperCorner>1612550.71909057 4841485.77342483</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.55"><gml:pos>1612550.71909057 4841485.77342483</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.55</ogr:fid>
      <ogr:nome>COLLEZIONI UNIVERSITARIE: Gipsoteca di Arte C</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Santa Maria 8</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.56">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612561.68329049 4841339.42468279</gml:lowerCorner><gml:upperCorner>1612561.68329049 4841339.42468279</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.56"><gml:pos>1612561.68329049 4841339.42468279</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.56</ogr:fid>
      <ogr:nome>Museo Nazionale di Palazzo Reale</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Lung.no Pacinotti 46</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe xsi:nil="true"/>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.57">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612187.63210184 4841146.44691043</gml:lowerCorner><gml:upperCorner>1612187.63210184 4841146.44691043</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.57"><gml:pos>1612187.63210184 4841146.44691043</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.57</ogr:fid>
      <ogr:nome>Museo delle navi</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Lungarno Simonelli</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.58">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1654637.92154747 4785779.02121346</gml:lowerCorner><gml:upperCorner>1654637.92154747 4785779.02121346</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.58"><gml:pos>1654637.92154747 4785779.02121346</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.58</ogr:fid>
      <ogr:nome>Acque Populoniae - Area Archeologica delle terme de bagno</ogr:nome>
      <ogr:comune>CASTELNUOVO DI VAL DI CECINA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>sl</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.59">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1651753.93023773 4781091.49789125</gml:lowerCorner><gml:upperCorner>1651753.93023773 4781091.49789125</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.59"><gml:pos>1651753.93023773 4781091.49789125</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.59</ogr:fid>
      <ogr:nome>Antiquarium di Sasso Pisano</ogr:nome>
      <ogr:comune>CASTELNUOVO DI VAL DI CECINA</ogr:comune>
      <ogr:indirizzo xsi:nil="true"/>
      <ogr:localita>Sasso Pisano</ogr:localita>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>sl</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.60">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1622408.09300785 4824940.09850306</gml:lowerCorner><gml:upperCorner>1622408.09300785 4824940.09850306</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.60"><gml:pos>1622408.09300785 4824940.09850306</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.60</ogr:fid>
      <ogr:nome>Museo Giorgio Kienerk</ogr:nome>
      <ogr:comune>FAUGLIA</ogr:comune>
      <ogr:indirizzo>Via Chiostra I, 13</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.61">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1628547.41078598 4823245.1715226</gml:lowerCorner><gml:upperCorner>1628547.41078598 4823245.1715226</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.61"><gml:pos>1628547.41078598 4823245.1715226</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.61</ogr:fid>
      <ogr:nome>Museo delle Attività agricole</ogr:nome>
      <ogr:comune>LARI</ogr:comune>
      <ogr:indirizzo>Via della Cella, 4</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.62">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1639031.63325371 4823266.9834978</gml:lowerCorner><gml:upperCorner>1639031.63325371 4823266.9834978</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.62"><gml:pos>1639031.63325371 4823266.9834978</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.62</ogr:fid>
      <ogr:nome>Museo Archeologico</ogr:nome>
      <ogr:comune>PECCIOLI</ogr:comune>
      <ogr:indirizzo>Piazza del Carmine, 33</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.63">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1639031.87880157 4823069.98706386</gml:lowerCorner><gml:upperCorner>1639031.87880157 4823069.98706386</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.63"><gml:pos>1639031.87880157 4823069.98706386</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.63</ogr:fid>
      <ogr:nome>Museo dell'arte sacra</ogr:nome>
      <ogr:comune>PECCIOLI</ogr:comune>
      <ogr:indirizzo>Piazza Frà Domenico da Peccioli</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>sv</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.64">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1652031.6407951 4795696.23642931</gml:lowerCorner><gml:upperCorner>1652031.6407951 4795696.23642931</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.64"><gml:pos>1652031.6407951 4795696.23642931</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.64</ogr:fid>
      <ogr:nome>Museo guerrieri e artigiani</ogr:nome>
      <ogr:comune>POMARANCE</ogr:comune>
      <ogr:indirizzo>Via Roncalli, 14</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.65">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1652058.56619224 4795673.15752945</gml:lowerCorner><gml:upperCorner>1652058.56619224 4795673.15752945</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.65"><gml:pos>1652058.56619224 4795673.15752945</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.65</ogr:fid>
      <ogr:nome>Casa Museo Bicocchi</ogr:nome>
      <ogr:comune>POMARANCE</ogr:comune>
      <ogr:indirizzo>Via Roncalli, 20</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Etnografia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.66">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1613220.50674802 4848247.29429313</gml:lowerCorner><gml:upperCorner>1613220.50674802 4848247.29429313</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.66"><gml:pos>1613220.50674802 4848247.29429313</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.66</ogr:fid>
      <ogr:nome>Museo del costume - Fondazione Cerratelli</ogr:nome>
      <ogr:comune>SAN GIULIANO TERME</ogr:comune>
      <ogr:indirizzo>Via G. di Vittorio, 2</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>sv</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.67">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1639041.6191598 4823073.47259448</gml:lowerCorner><gml:upperCorner>1639041.6191598 4823073.47259448</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.67"><gml:pos>1639041.6191598 4823073.47259448</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.67</ogr:fid>
      <ogr:nome>Museo di incisioni e litografie - Donazione Vito Merlini</ogr:nome>
      <ogr:comune>PECCIOLI</ogr:comune>
      <ogr:indirizzo>Piazza Frà Domenico da Peccioli</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>sv</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.68">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612745.64012337 4841255.77618078</gml:lowerCorner><gml:upperCorner>1612745.64012337 4841255.77618078</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.68"><gml:pos>1612745.64012337 4841255.77618078</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.68</ogr:fid>
      <ogr:nome>Blu Palazzo Museo d'Arte e Cultura</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Lung.no Gambagorti, 32</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.69">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1611765.21645174 4841846.78995774</gml:lowerCorner><gml:upperCorner>1611765.21645174 4841846.78995774</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.69"><gml:pos>1611765.21645174 4841846.78995774</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.69</ogr:fid>
      <ogr:nome>Cantiere delle Navi Antiche di Pisa e centro di restauro del legno bagnato</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Via Ranuccio Bianche Bandinelli</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.70">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612434.58815724 4842102.78057322</gml:lowerCorner><gml:upperCorner>1612434.58815724 4842102.78057322</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.70"><gml:pos>1612434.58815724 4842102.78057322</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.70</ogr:fid>
      <ogr:nome>Cattedrale di Santa Maria</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>PIazza del Duomo</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.71">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612320.20904168 4842102.78057322</gml:lowerCorner><gml:upperCorner>1612320.20904168 4842102.78057322</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.71"><gml:pos>1612320.20904168 4842102.78057322</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.71</ogr:fid>
      <ogr:nome>Battistero</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>PIazza del Duomo</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.72">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612539.96104356 4841205.76002338</gml:lowerCorner><gml:upperCorner>1612539.96104356 4841205.76002338</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.72"><gml:pos>1612539.96104356 4841205.76002338</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.72</ogr:fid>
      <ogr:nome>Chiesa di Santa Maria della Spina</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Lung.no Gambacorti</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.73">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1613235.19850601 4841063.34536951</gml:lowerCorner><gml:upperCorner>1613235.19850601 4841063.34536951</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.73"><gml:pos>1613235.19850601 4841063.34536951</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.73</ogr:fid>
      <ogr:nome>Museo della Grafica</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Lung.no G. Galilei, 9</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.74">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612062.10048691 4841037.21516352</gml:lowerCorner><gml:upperCorner>1612062.10048691 4841037.21516352</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.74"><gml:pos>1612062.10048691 4841037.21516352</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.74</ogr:fid>
      <ogr:nome>Torre Guelfa della Cittadella vecchia</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Lung.no Simonelli - Piazza Tersanaia</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.75">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1612522.55015427 4842066.65519914</gml:lowerCorner><gml:upperCorner>1612522.55015427 4842066.65519914</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.75"><gml:pos>1612522.55015427 4842066.65519914</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.75</ogr:fid>
      <ogr:nome>PISA</ogr:nome>
      <ogr:comune>PISA</ogr:comune>
      <ogr:indirizzo>Piazza del Duomo</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.76">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1649398.15276218 4838004.89811414</gml:lowerCorner><gml:upperCorner>1649398.15276218 4838004.89811414</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.76"><gml:pos>1649398.15276218 4838004.89811414</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.76</ogr:fid>
      <ogr:nome>Oratorio dell'Oretino</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo>Via Vittime del Duomo, 11</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>sv</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.77">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1649383.89786898 4838112.063219</gml:lowerCorner><gml:upperCorner>1649383.89786898 4838112.063219</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.77"><gml:pos>1649383.89786898 4838112.063219</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.77</ogr:fid>
      <ogr:nome>Rocca di Federico II</ogr:nome>
      <ogr:comune>SAN MINIATO</ogr:comune>
      <ogr:indirizzo>sommitale</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.78">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1636419.51299703 4839681.23617072</gml:lowerCorner><gml:upperCorner>1636419.51299703 4839681.23617072</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.78"><gml:pos>1636419.51299703 4839681.23617072</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.78</ogr:fid>
      <ogr:nome>Museo Casa Carducci</ogr:nome>
      <ogr:comune>SANTA MARIA A MONTE</ogr:comune>
      <ogr:indirizzo>Via Carducci, 29</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Storia</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.79">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1650549.80425706 4807146.82766769</gml:lowerCorner><gml:upperCorner>1650549.80425706 4807146.82766769</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.79"><gml:pos>1650549.80425706 4807146.82766769</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.79</ogr:fid>
      <ogr:nome>Palazzo dei Priori</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo>Piazza dei Priori</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>sv</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.80">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1650641.5719315 4807350.23474882</gml:lowerCorner><gml:upperCorner>1650641.5719315 4807350.23474882</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.80"><gml:pos>1650641.5719315 4807350.23474882</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.80</ogr:fid>
      <ogr:nome>Aree Archeologiche</ogr:nome>
      <ogr:comune>VOLTERRA</ogr:comune>
      <ogr:indirizzo>Via Ferrucci</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Archeologia</ogr:classe>
      <ogr:localizzaz xsi:nil="true"/>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
  <ogr:featureMember>
    <ogr:metarepo_resources.musei_r1 gml:id="metarepo_resources.musei_r1.81">
      <gml:boundedBy><gml:Envelope srsName="urn:ogc:def:crs:EPSG::3003"><gml:lowerCorner>1627893.49870461 4839713.95329532</gml:lowerCorner><gml:upperCorner>1627893.49870461 4839713.95329532</gml:upperCorner></gml:Envelope></gml:boundedBy>
      <ogr:geom><gml:Point srsName="urn:ogc:def:crs:EPSG::3003" gml:id="metarepo_resources.musei_r1.geom.81"><gml:pos>1627893.49870461 4839713.95329532</gml:pos></gml:Point></ogr:geom>
      <ogr:fid>5885e8f1182ba.81</ogr:fid>
      <ogr:nome>Rocca del Brunelleschi e Palazzo Pretorio</ogr:nome>
      <ogr:comune>VICOPISANO</ogr:comune>
      <ogr:indirizzo>Via del Pretorio, 25</ogr:indirizzo>
      <ogr:localita xsi:nil="true"/>
      <ogr:classe>Arte</ogr:classe>
      <ogr:localizzaz>ok</ogr:localizzaz>
    </ogr:metarepo_resources.musei_r1>
  </ogr:featureMember>
</ogr:FeatureCollection>
